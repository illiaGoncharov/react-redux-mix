import React from 'react';

export const TotalCostContext = React.createContext(null);
export const DiscountContext = React.createContext(null);